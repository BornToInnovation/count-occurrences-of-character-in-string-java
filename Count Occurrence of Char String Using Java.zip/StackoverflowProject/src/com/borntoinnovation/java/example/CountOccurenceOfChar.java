package com.borntoinnovation.java.example;

import java.util.HashMap;

/*
 * This example will count the occurrence of char/number using Hashmap.
 */
public class CountOccurenceOfChar {

	public static void getOccurenceCount(String message) {
		// Create Hashmap to store element
		HashMap<Character, Integer> countMap = new HashMap<Character, Integer>();
		
		// Convert String to char array
		char[] charMsgArray = message.toCharArray();
		
		// Iterate each char array and compare their key with char.
		for(char ch : charMsgArray) {
			// If key matched then their count increment by 1
			if(countMap.containsKey(ch)) {
				countMap.put(ch, countMap.get(ch)+1);
				// If their key doesn't match then count remains 1
			}else {
				countMap.put(ch, 1);
			}
		}
		
		System.out.println(countMap);
	}
	
	public static void main(String[] args) {
		getOccurenceCount("Hello Buddy, Good Morning");
		
		getOccurenceCount("Born To Innovation");
		
		getOccurenceCount("+91-9660768286");
	}

}

/*
 * Output: (Including Blank Space count)
	{ =3, B=1, d=3, e=1, G=1, g=1, H=1, i=1, l=2, ,=1, M=1, n=2, o=4, r=1, u=1, y=1}
	{ =2, a=1, B=1, r=1, T=1, t=1, v=1, I=1, i=1, n=4, o=4}
	{0=1, 1=1, 2=1, 6=4, 7=1, 8=2, 9=2, +=1, -=1}
 *
 */
